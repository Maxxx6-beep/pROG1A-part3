/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chattaapppart1;
import java.util.Scanner;
/**
 *
 * @author Student
 */
public class ChattAAppPart1 {

    public static void main(String[] args) {
         Scanner input = new Scanner(System.in);
         
         Login login = new Login();
         boolean isLoggedin = true;
         if(isLoggedin) {
         System.out.print("Wellcome to Quickchat");     
    } else { 
    
     System.out.print("");
     return;
     
}
System.out.println("\n. Send Messages");
System.out.println("");
System.out.println("3. Quit");

System.out.print("please choose option");
switch(menuOptions) {
    case 1:
        System.out.print("how many messages you want to send");
        int totalMessages = Scanner.nextInt();
        scanner.nextLine();
        int sentMessages = 0; 
        System.out.print("please enter receipt number");
        String receipt= scanner.nextLine();
        System.out.print("please enter Message");
        String messagetext= scanner.nextLine();
        Message msg=
                new Message(i,receipt,messagetex);
        if(!msg.checkMessageID()) {
            System.out.println("invalid message");
           
        }
        if(msg.checkMessageLength()) {
            System.out.println("Please enter message that is no more than 50 characyers");
            
        }
    case 3:
        System.out.println("Goodbye");
        break;
    default:
        System.out.println("invalid menu option");
        
     case 2:
        System.out.println("Comming soon");
        break;   
        
}
}
  
    

