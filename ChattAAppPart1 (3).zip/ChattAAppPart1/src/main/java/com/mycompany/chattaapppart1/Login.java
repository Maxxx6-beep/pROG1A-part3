/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chattaapppart1;

/**
 *
 * @author Student
 */
public class Login {
    String Password;
    String UserName;
    String phone;
    
    
    public Login(String Password,String UserName,String CellphoneNumber){
        this.Password = Password;
        this.UserName = UserName;
        this.phone = phone;
        
    
    }

    Login() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
public boolean checkUserName(String UserName) {
        if (UserName.length()>= 5 && UserName.contains("_")){
    System.out.println("UserName is succesfully captured");
    return true;
} else {
    System.out.println("Please ensure username is no more than 5 characters and contains an underscore");
    return false;
}
        
 public boolean checkphone() {
     if (phone.startsWith("+27") && phone.length() <=13) {
         System.out.println("The number is correct");
         return true;
     } else {
         System.out.println("The number is not right");
         return false;
     }
     
 }
 public String getUserName() {
     return UserName;
 }
 public String getphone() {
     return phone;
 }
    }