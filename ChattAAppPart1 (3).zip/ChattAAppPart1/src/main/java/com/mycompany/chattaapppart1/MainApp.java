/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chattaapppart1;
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class MainApp {
    public static void main(String [] args) {
        Scanner input = new Scanner(System.in);
    
    System.out.println("=== User Regestration ===");
    System.out.println("Please Enter UserName");
    String UserName = input.nextLine();
    System.out.println("Please Enter Password");
    String Password = input.nextLine();
    System.out.println("Please Enter your South African Phone number");
    String phone = input.nextLine();
    Registration reg = new Registration(UserName,Password,phone);
    if ( reg.checkUserName()) {
        System.out.println("username is correct");
        
    } else {
        System.out.println("Username is not correct");
        return;
    }
        if ( reg.checkPassword()) {
        System.out.println("Password is correct");
        
    } else {
        System.out.println("Passwordis not correct");
        return;
    }
        if ( reg.checkPhone()) {
        System.out.println("Phone number is correct");
        
    } else {
        System.out.println("Phone number is not correct");
        return;
        }
   
    
    
    System.out.println("=== User Login ==");
    System.out.println("Enter UserName");
    String LoginUserName = input.nextLine();
    System.out.println("Enter Password");
    String LoginPassword = input.nextLine();
    Login login = new Login();
    if(login.loginUser(LoginUserName, LoginPassword, reg)) {
        System.out.println("Login Succesfully");
        
    } else{
        System.out.println("Login is not succesfully");
    }
    input.close();
    }
    


}

