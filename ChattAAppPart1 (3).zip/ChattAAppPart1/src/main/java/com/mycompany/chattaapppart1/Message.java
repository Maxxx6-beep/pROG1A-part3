/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chattaapppart1;
import java.util.ArrayList;
import java.util.Random;
/**
 *
 * @author Student
 */
public class Message {
   private String receipt;
   private  int Messagenumber;
   private long MessageID;
   private String messagehash;
   private String messagetext;
   
   public Message (int Messagenumber, String receipt,String messagetext ) {
       this.messagetext = messagetext;
       this.receipt = receipt;
       this.Messagenumber = Messagenumber;
       generateMessageID();
       createmessagehas();
   }
   public void generateMessageID() {
       Random random = new Random();
       MessageID = 10000000000L +
               ((long )(random.nextDouble()* 9000000000L));
       
   }
   public boolean checkMessageID() {
       return String.valueOf(MessageID).length() == 10;
   }
   public void createmessagehash() {
       String [] words = messagetext.split("");
      messagehash = 
              String.valueOf(MessageID).substring(0,2);
      + ":" + Messagenumber + ":"
              + words[0].toUpperCase()
              + words[words.length - 1].toUpperCase();
   }
    public boolean checkMessageLength() {
        return messagetext.length() <=250;
       
    }
     public boolean checkreceiptcell() {
         if (receipt.startsWith("+") &&
           receipt.length()<=10){
          System.out.println("the cellphone number is captured");
         } else{
             System.out.println("the cellphone is not correctly formatted or it does not carry international code");
         }
         
     } 
     public String sentmessage(int option) {
         switch(option) {
             case 1:
                 sentmessages.add(messageText);
                 
                 return "The Message is successfully sent";
              case 2:
                 return "To delete press 0";
               case 3:
                 return "The Message is successfully stored";  
               default:  
                   return "invalid option";
     }
         public static ArrayList<String> sentmesages =
                 new ArrayList<>();
         public static ArrayList<String> messageHashes =
                 new ArrayList<>();
         public static ArrayList<String> storedMessages =
                 new ArrayList<>();
         public static ArrayList<String> disregardedMessages =
                 new ArrayList<>();
         public static ArrayList<String> MessageIDs =
                 new ArrayList<>();
     }

public String sentmessage(int option) {
         switch(option) {
             case 1:
                 sentmessages.add(messageText);
                 messageHashes.add(messsageHash);
                 messageIDs.add(messageID);
                 totalMessages++;
                  return "The Message is successfully sent";
                  
                  case 2:
                      disregardedMessages.add(messageText);
                 return "disregarded";
                  case 3:
                      sentmessages.add(messageText);
                 messageHashes.add(messsageHash);
                 messageIDs.add(messageID);
                 
                 return "The Message is successfully stored";  

                         default;
                       
         }
         public static void StoredMessagesMenu() {
           System.out.println("Stored Message Menu");
           
            System.out.println("1.display sender and reciept");
             System.out.println("2. display longest stored message");
              System.out.println("3. search by message id");
               System.out.println("4. Search by receipt");
                System.out.println("5.Delete using hash");
                 System.out.println("6.Display report");
                 int choice = scanner.nextInt();
                 scanner.nextInt();
                 switch(choice) {
                      case 1:
                          displayStoredMessages(scanner);
                          break;
                            case 2:
                          displayLongestMessage(scanner);
                          break;
                          case 3:
                          searchtMessageID(scanner);
                          break;
                          case 4:
                          searchRecieptient(scanner);
                          break;
                          case 5:
                          deleteMessageHash(scanner);
                          break;
                 }
                     public static void displayLongestMessage () {
                       String longest = ""  ;
                       for(String msg: Message.storedMessages) {
                           if(msg.length() > longest.length()) {
                               longest = msg;
                           }
                           System.out.println("Longest Message");
                           System.out.println(longest);
                           
                       }
               public static void searchMessageID (Scanner scanner) {
                   System.out.print("Enter Message ID");
                   long = id= scanner.nextLong();
                   int index = Message.MessageIDs.indexOf(ID);
                   if(index  != 1) {
                       System.out.println(Message.storedMessages.indexOf(index));
                   } else {
                       System.out.println("Not found");
                   }
               }
                     
                     }
                      public static void displayReport () {
                     System.out.println("Stored message report");
                     for(int i = 0;
                             i < Message.storedMessages.size();
                             
                             
                             ++i) {
                          System.out.println("MessageID"+ Message.MessageIDs.get(i));
                          System.out.println("hash"+ Message.messageHashes.get(i));
                          System.out.println("MessageID"+ Message.storedMessages.get(i));
                     }
                 }
                 

         
         


