/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chattaapppart1;

/**
 *
 * @author Student
 */
class Registration {
    String Password;
    String UserName;
    String phone;
 
    
    public Registration(String Password,String UserName,String CellphoneNumber) {
        this.Password = Password;
        this.UserName = UserName;
        this.phone =CellphoneNumber ;    
}
public boolean checkUserName(String UserName) {
    return UserName.length() >5 && UserName.contains("_");
}
 public boolean checkPassword() {
     return Password.length() >=8;
 }
 public boolean checkphone() {
  return phone.startsWith("+27") && phone.length() <13;
 }
 public String getUserName(){
     return UserName;
 }
public String getPasswors(){
     return UserName;
}
}